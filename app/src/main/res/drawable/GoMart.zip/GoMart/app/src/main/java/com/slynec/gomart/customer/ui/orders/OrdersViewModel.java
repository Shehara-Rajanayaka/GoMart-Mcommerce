package com.slynec.gomart.customer.ui.orders;

import androidx.lifecycle.ViewModel;

public class OrdersViewModel extends ViewModel {


}