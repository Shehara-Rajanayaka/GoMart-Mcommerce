package com.slynec.gomart.customer.ui.profile;

import androidx.lifecycle.ViewModel;

public class NavigationProfileViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}