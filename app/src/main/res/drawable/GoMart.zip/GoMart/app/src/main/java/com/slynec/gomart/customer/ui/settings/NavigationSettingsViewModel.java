package com.slynec.gomart.customer.ui.settings;

import androidx.lifecycle.ViewModel;

public class NavigationSettingsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}